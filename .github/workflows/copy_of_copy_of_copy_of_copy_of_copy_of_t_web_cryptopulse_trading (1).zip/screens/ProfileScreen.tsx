
import * as React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronRight, Bell, Lock, Sun, Moon, CreditCard, Download, Repeat, ArrowLeft, HelpCircle, Mail, User as UserIcon, Users, LogOut, AlertCircle, Loader, Camera, ShieldCheck, CheckCircle2, Clock, XCircle, ArrowDownLeft, ArrowUpRight, MailCheck, LifeBuoy } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { User, Transaction, KYCStatus, Notification } from '../types.ts';
import { useTheme } from '../contexts/ThemeContext.tsx';
import { useAppContext } from '../contexts/AppContext.tsx';

// --- Reusable Components & Helpers ---

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const FormInput = ({ id, label, type = 'text', value, onChange, placeholder = '', required = true }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
        <input
            type={type}
            id={id}
            name={id}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            required={required}
            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-purple-500 focus:border-purple-500"
        />
    </div>
);

const CountrySelect = ({ id, value, onChange }) => {
    const countries = [ "Brazil", "United States", "Canada", "United Kingdom", "Germany", "France", "Japan", "Australia", "India", "Mexico", "Argentina", "South Korea" ];
    return (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300">Country</label>
            <select
                id={id}
                name={id}
                value={value}
                onChange={onChange}
                required
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
            >
                <option value="">Select a country</option>
                {countries.map(country => <option key={country} value={country}>{country}</option>)}
            </select>
        </div>
    );
};


const KycStatusBadge = ({ status, onClick }: { status: KYCStatus; onClick?: () => void }) => {
    const statusInfo = {
        verified: { Icon: CheckCircle2, text: 'Verified', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
        pending: { Icon: Clock, text: 'Pending Review', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' },
        unverified: { Icon: AlertCircle, text: 'Unverified', className: 'bg-gray-200 text-gray-800 dark:bg-slate-700 dark:text-slate-300' },
        rejected: { Icon: XCircle, text: 'Rejected', className: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' },
    }[status];

    const Tag = onClick ? 'button' : 'span';

    return (
        <Tag
            onClick={onClick}
            className={`mt-2 inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide ${statusInfo.className} ${onClick ? 'hover:opacity-80 transition-opacity' : ''}`}
        >
            <statusInfo.Icon size={14} className="mr-1.5" />
            {statusInfo.text}
        </Tag>
    );
};

const MenuItem = ({ icon, label, onClick, badge }: { icon: React.ReactNode; label: string; onClick: () => void; badge?: number; }) => (
    <button onClick={onClick} className="w-full flex items-center justify-between p-4 bg-white dark:bg-slate-800/50 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors shadow-sm dark:shadow-none">
        <div className="flex items-center space-x-4">
            {icon}
            <span className="font-medium text-slate-900 dark:text-white">{label}</span>
        </div>
        <div className="flex items-center space-x-3">
            {badge > 0 && (
                <span className="bg-purple-500 text-white text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full">{badge}</span>
            )}
            <ChevronRight size={20} className="text-gray-400 dark:text-gray-500" />
        </div>
    </button>
);


const ViewContainer = ({ title, onBack, children }: { title: string; onBack: () => void; children: React.ReactNode }) => (
    <div className="animate-fade-in">
        <header className="flex items-center mb-6">
            <button onClick={onBack} className="p-2 mr-2 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700">
                <ArrowLeft size={24} />
            </button>
            <h2 className="text-2xl font-bold">{title}</h2>
        </header>
        {children}
    </div>
);

// --- Sub-Views ---

const AssetsView = ({ user, setView, onLogout, isAdmin }: { user: User, setView: (view: string) => void, onLogout: () => void, isAdmin: boolean }) => {
    const { theme, toggleTheme } = useTheme();
    const { openTelegramModal } = useAppContext();
    const navigate = useNavigate();
    const { updateUserPhoto, isLoading } = useAuth();
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const unreadCount = user.notifications.filter(n => !n.read).length;

    const handleAvatarClick = () => {
        if (!isLoading) {
            fileInputRef.current?.click();
        }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            try {
                await updateUserPhoto(file);
            } catch (error) {
                console.error("Failed to upload photo", error);
                alert("Photo upload failed. Please try again.");
            }
        }
    };

    return (
        <div className="animate-fade-in space-y-6">
            <header className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Assets</h1>
                <button onClick={onLogout} title="Log Out" className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors">
                    <LogOut size={22} className="text-red-500 dark:text-red-400" />
                </button>
            </header>

            {/* User Info & Balance Card */}
            <div className="bg-white dark:bg-slate-800/50 p-6 rounded-2xl shadow-sm dark:shadow-none space-y-4">
                <div className="flex items-center space-x-4">
                    <div className="relative">
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            accept="image/*"
                            className="hidden"
                            disabled={isLoading}
                        />
                        <button onClick={handleAvatarClick} disabled={isLoading} className="relative w-20 h-20 rounded-full group cursor-pointer disabled:cursor-wait">
                            {user.photoURL ? (
                                <img src={user.photoURL} alt="Profile" className="w-full h-full rounded-full object-cover" />
                            ) : (
                                <div className="w-full h-full rounded-full bg-purple-500 flex items-center justify-center">
                                    <UserIcon size={40} className="text-white" />
                                </div>
                            )}
                            <div className={`absolute inset-0 rounded-full bg-black/50 flex items-center justify-center transition-opacity ${isLoading ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                                {isLoading ? <Loader className="animate-spin text-white" /> : <Camera size={24} className="text-white" />}
                            </div>
                        </button>
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-slate-900 dark:text-white">{user.name}</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400">ID: {user.uid}</p>
                        <KycStatusBadge status={user.kycStatus} onClick={() => setView('kyc')} />
                    </div>
                </div>
                
                <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Account Balance (USDT)</p>
                    <p className="text-5xl font-bold tracking-tighter text-slate-900 dark:text-white">
                        {user.portfolio.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                </div>
            </div>
            
            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
                <button onClick={() => setView('deposit')} className="flex items-center justify-center gap-3 bg-white dark:bg-slate-800/50 p-4 rounded-xl shadow-sm dark:shadow-none font-semibold text-lg transition hover:scale-105 hover:bg-gray-50 dark:hover:bg-slate-800">
                    <ArrowDownLeft size={24} className="text-green-500"/>
                    <span className="text-slate-900 dark:text-white">Deposit</span>
                </button>
                <button onClick={() => setView('withdraw')} className="flex items-center justify-center gap-3 bg-white dark:bg-slate-800/50 p-4 rounded-xl shadow-sm dark:shadow-none font-semibold text-lg transition hover:scale-105 hover:bg-gray-50 dark:hover:bg-slate-800">
                    <ArrowUpRight size={24} className="text-yellow-500"/>
                    <span className="text-slate-900 dark:text-white">Withdraw</span>
                </button>
            </div>

            {/* Other menu items */}
            <div className="space-y-2 pt-4">
                {isAdmin && (
                     <MenuItem icon={<ShieldCheck size={20} className="text-purple-500 dark:text-purple-400"/>} label="Admin Panel" onClick={() => navigate('/admin')} />
                )}
                <MenuItem icon={<ShieldCheck size={20} />} label="Identity Verification" onClick={() => setView('kyc')} />
                <MenuItem icon={<Repeat size={20} />} label="Transaction History" onClick={() => navigate('/history')} />
                <MenuItem icon={<Bell size={20} />} label="Notifications" onClick={() => setView('notifications')} badge={unreadCount} />
                <MenuItem icon={<LifeBuoy size={20} />} label="Customer Service" onClick={openTelegramModal} />
                <button onClick={toggleTheme} className="w-full flex items-center justify-between p-4 bg-white dark:bg-slate-800/50 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors shadow-sm dark:shadow-none">
                    <div className="flex items-center space-x-4">
                        {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                        <span className="font-medium text-slate-900 dark:text-white">Theme</span>
                    </div>
                    <span className="text-gray-500 dark:text-gray-400 capitalize">{theme}</span>
                </button>
            </div>
        </div>
    );
};

const KycView = ({ user, onBack }) => {
    const { submitKyc, isLoading } = useAuth();
    const [formData, setFormData] = React.useState({
        fullName: user.fullName || user.name || '',
        dateOfBirth: user.dateOfBirth || '',
        country: user.country || '',
        address: user.address || '',
    });
    const [idFront, setIdFront] = React.useState<File | null>(null);
    const [idBack, setIdBack] = React.useState<File | null>(null);
    const [error, setError] = React.useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<File | null>>) => {
        const file = e.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            setter(file);
        } else {
            e.target.value = '';
            setter(null);
            alert("Please select a valid image file.");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!idFront || !idBack) {
            setError('Please upload images of the front and back of your ID.');
            return;
        }
        try {
            const idFrontBase64 = await toBase64(idFront);
            const idBackBase64 = await toBase64(idBack);
            await submitKyc({ ...formData, idFrontBase64, idBackBase64 });
            onBack(); // Go back after successful submission
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred.');
        }
    };
    
    if (user.kycStatus === 'verified') {
        return (
            <ViewContainer title="Identity Verification" onBack={onBack}>
                <div className="text-center p-8 bg-white dark:bg-slate-800/50 rounded-lg">
                    <CheckCircle2 size={64} className="mx-auto text-green-500" />
                    <h3 className="mt-4 text-xl font-bold">You're Verified!</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">Your identity has been successfully verified. You have full access to all features.</p>
                </div>
            </ViewContainer>
        );
    }
    
    if (user.kycStatus === 'pending') {
        return (
             <ViewContainer title="Identity Verification" onBack={onBack}>
                <div className="text-center p-8 bg-white dark:bg-slate-800/50 rounded-lg">
                    <Clock size={64} className="mx-auto text-yellow-500" />
                    <h3 className="mt-4 text-xl font-bold">Verification Pending</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">Your documents are under review. This usually takes 1-3 business days. We'll notify you once it's complete.</p>
                </div>
            </ViewContainer>
        );
    }

    return (
        <ViewContainer title="Identity Verification" onBack={onBack}>
            <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-white dark:bg-slate-800/50 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-300">Please provide your legal information as it appears on your government-issued ID.</p>
                
                {user.kycStatus === 'rejected' && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-lg">
                        Your previous submission was rejected. Please review your information and try again.
                    </div>
                )}

                <FormInput id="fullName" label="Full Legal Name" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} placeholder="Your full legal name" />
                <FormInput id="dateOfBirth" label="Date of Birth" type="date" value={formData.dateOfBirth} onChange={e => setFormData({...formData, dateOfBirth: e.target.value})} />
                <CountrySelect id="country" value={formData.country} onChange={e => setFormData({...formData, country: e.target.value})} />
                <FormInput id="address" label="Residential Address" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} placeholder="123 Crypto Lane" />

                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ID Front</label>
                    <input type="file" accept="image/*" onChange={e => handleFileChange(e, setIdFront)} className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ID Back</label>
                    <input type="file" accept="image/*" onChange={e => handleFileChange(e, setIdBack)} className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" />
                </div>
                
                {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400 disabled:cursor-not-allowed">
                    {isLoading ? <Loader className="animate-spin" /> : 'Submit for Verification'}
                </button>
            </form>
        </ViewContainer>
    );
};

const DepositView = ({ onBack }) => {
    const { deposit, isLoading } = useAuth();
    const [network, setNetwork] = React.useState<'TRC20' | 'ERC20' | 'BTC'>('TRC20');
    const [amount, setAmount] = React.useState('');
    const [txProof, setTxProof] = React.useState<File | null>(null);
    const [txProofPreview, setTxProofPreview] = React.useState<string | null>(null);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    const networks = {
        'TRC20': { name: 'TRC20 (USDT)', address: 'TQjXg7Yt2Zk5p2eJ1wE9aXvCqR6bS3nK9s', asset: 'USDT' },
        'ERC20': { name: 'ERC20 (USDT)', address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e', asset: 'USDT' },
        'BTC': { name: 'Bitcoin', address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', asset: 'BTC' },
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            setTxProof(file);
            setTxProofPreview(URL.createObjectURL(file));
        } else {
            if(file) alert("Please select a valid image file.");
            e.target.value = '';
            setTxProof(null);
            setTxProofPreview(null);
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!amount || parseFloat(amount) <= 0) {
            setError('Please enter a valid amount.');
            return;
        }
        if (!txProof) {
            setError('Please upload a transaction proof screenshot.');
            return;
        }

        try {
            const proofBase64 = await toBase64(txProof);
            await deposit({
                amount: parseFloat(amount),
                network,
                asset: networks[network].asset,
                transactionProof: proofBase64
            });
            setSuccess('Deposit submitted successfully! It will be reviewed shortly.');
            setAmount('');
            setTxProof(null);
            setTxProofPreview(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Deposit submission failed.');
        }
    };
    
    return (
        <ViewContainer title="Deposit Funds" onBack={onBack}>
            <div className="space-y-6 p-4 bg-white dark:bg-slate-800/50 rounded-lg">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Network</label>
                    <div className="mt-2 grid grid-cols-3 gap-2 rounded-lg bg-gray-200 dark:bg-slate-900 p-1">
                        {Object.keys(networks).map((net) => (
                            <button
                                key={net}
                                onClick={() => setNetwork(net as 'TRC20' | 'ERC20' | 'BTC')}
                                className={`px-3 py-2 text-sm font-semibold rounded-md transition-colors ${network === net ? 'bg-white text-purple-600 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-gray-600 hover:bg-white/50 dark:text-gray-400 dark:hover:bg-slate-800/50'}`}
                            >
                                {networks[net].name}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="p-4 border border-dashed border-gray-300 dark:border-slate-600 rounded-lg">
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Send only {networks[network].asset} to this address.</p>
                    <p className="text-sm font-mono break-all text-slate-800 dark:text-slate-200">{networks[network].address}</p>
                    <button 
                      onClick={() => navigator.clipboard.writeText(networks[network].address)}
                      className="mt-2 text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline"
                    >
                      Copy Address
                    </button>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                     <FormInput
                        id="amount"
                        label={`Amount (${networks[network].asset})`}
                        type="number"
                        value={amount}
                        onChange={e => setAmount(e.target.value)}
                        placeholder="0.00"
                    />
                     <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Transaction Proof</label>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Upload a screenshot of your transaction confirmation.</p>
                         <input 
                            type="file" 
                            accept="image/*" 
                            onChange={handleFileChange} 
                            className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" 
                        />
                         {txProofPreview && (
                            <div className="mt-4">
                               <img src={txProofPreview} alt="Transaction proof preview" className="rounded-lg max-h-48 w-auto mx-auto border dark:border-slate-700"/>
                            </div>
                         )}
                    </div>

                    {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                    {success && <p className="text-sm text-green-500 dark:text-green-400">{success}</p>}

                    <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400 disabled:cursor-not-allowed">
                        {isLoading ? <Loader className="animate-spin" /> : 'Submit Deposit'}
                    </button>
                </form>

            </div>
        </ViewContainer>
    );
};

const WithdrawView = ({ onBack }) => {
    const { withdraw, user, isLoading } = useAuth();
    const [password, setPassword] = React.useState('');
    const [amount, setAmount] = React.useState('');
    const [address, setAddress] = React.useState('');
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        try {
            await withdraw(password, { amount: parseFloat(amount), address, asset: 'USDT' });
            setSuccess(`Successfully withdrew ${amount} USDT.`);
            setPassword(''); setAmount(''); setAddress('');
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Withdrawal failed.');
        }
    };
    
    if (user.kycStatus !== 'verified') {
       return (
            <ViewContainer title="Withdraw Funds" onBack={onBack}>
                <div className="p-4 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg text-yellow-800 dark:text-yellow-200">
                    <AlertCircle className="inline mr-2" />
                    Please verify your identity before making a withdrawal.
                </div>
            </ViewContainer>
        );
    }
    
    return (
        <ViewContainer title="Withdraw Funds" onBack={onBack}>
            <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-white dark:bg-slate-800/50 rounded-lg">
                <FormInput id="amount" label="Amount (USDT)" type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" />
                <FormInput id="address" label="Withdrawal Address (USDT)" value={address} onChange={e => setAddress(e.target.value)} placeholder="0x..." />
                <FormInput id="password" label="Confirm Password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
                
                {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                {success && <p className="text-sm text-green-500 dark:text-green-400">{success}</p>}
                
                 <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400">
                    {isLoading ? <Loader className="animate-spin" /> : 'Submit Withdrawal'}
                </button>
            </form>
        </ViewContainer>
    );
};

const NotificationsView = ({ user, onBack }: { user: User; onBack: () => void; }) => {
    const { markAllNotificationsAsRead, markNotificationAsRead, isLoading } = useAuth();

    const handleMarkAllRead = async () => {
        if (user.notifications.some(n => !n.read)) {
            await markAllNotificationsAsRead();
        }
    };
    
    const handleMarkOneRead = (notificationId: string) => {
        const notification = user.notifications.find(n => n.id === notificationId);
        if (notification && !notification.read) {
             markNotificationAsRead(notificationId);
        }
    }

    const sortedNotifications = [...user.notifications].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const notificationIcons = {
        transaction: <Repeat size={24} className="text-blue-500" />,
        security: <ShieldCheck size={24} className="text-yellow-500" />,
        system: <Bell size={24} className="text-purple-500" />,
    };

    return (
        <ViewContainer title="Notifications" onBack={onBack}>
            <div className="mb-4 flex justify-end">
                <button 
                    onClick={handleMarkAllRead}
                    disabled={isLoading || !user.notifications.some(n => !n.read)}
                    className="flex items-center px-3 py-1.5 bg-purple-100 dark:bg-slate-700 text-purple-700 dark:text-purple-300 rounded-md text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <MailCheck size={16} className="mr-2"/>
                    Mark all as read
                </button>
            </div>
            <div className="space-y-3">
                {sortedNotifications.length > 0 ? (
                    sortedNotifications.map(notification => (
                        <div 
                            key={notification.id} 
                            onClick={() => handleMarkOneRead(notification.id)}
                            className={`relative p-4 pl-8 bg-white dark:bg-slate-800/50 rounded-lg flex items-start space-x-4 border-l-4 transition-colors ${!notification.read ? 'border-purple-500 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-800' : 'border-transparent'}`}
                        >
                            {!notification.read && <div className="absolute left-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>}
                            <div className="flex-shrink-0 pt-1">
                                {notificationIcons[notification.type]}
                            </div>
                            <div className="flex-grow">
                                <p className={`font-bold ${!notification.read ? 'text-slate-900 dark:text-white' : 'text-gray-600 dark:text-gray-400'}`}>{notification.title}</p>
                                <p className={`text-sm mt-1 ${!notification.read ? 'text-gray-600 dark:text-gray-300' : 'text-gray-500 dark:text-gray-400'}`}>{notification.message}</p>
                                <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">{new Date(notification.date).toLocaleString()}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="text-center p-8 bg-white dark:bg-slate-800/50 rounded-lg">
                        <Bell size={48} className="mx-auto text-gray-400" />
                        <h3 className="mt-4 text-xl font-bold">You're all caught up!</h3>
                        <p className="mt-2 text-gray-500 dark:text-gray-400">You have no new notifications.</p>
                    </div>
                )}
            </div>
        </ViewContainer>
    );
};


const LoginSignupForm = () => {
  const [isLogin, setIsLogin] = React.useState(true);
  const [formData, setFormData] = React.useState({ name: '', email: '', password: '', dateOfBirth: '', country: '', address: '' });
  const [error, setError] = React.useState('');
  const { login, signup, isLoading } = useAuth();
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
        if (isLogin) {
            await login(formData.email, formData.password);
        } else {
            await signup(formData.name, formData.email, formData.password, { 
                dateOfBirth: formData.dateOfBirth, 
                country: formData.country, 
                address: formData.address 
            });
        }
    } catch (err) {
        setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-xl animate-fade-in">
        <h2 className="text-3xl font-bold text-center mb-2 text-slate-900 dark:text-white">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-6">{isLogin ? 'Log in to continue your trading journey.' : 'Join the future of finance.'}</p>
        <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && <FormInput id="name" label="Full Name" value={formData.name} onChange={handleChange} placeholder="Alex Johnson" />}
            <FormInput id="email" label="Email Address" type="email" value={formData.email} onChange={handleChange} placeholder="you@example.com" />
            <FormInput id="password" label="Password" type="password" value={formData.password} onChange={handleChange} placeholder="••••••••" />
            {!isLogin && (
                <>
                    <FormInput id="dateOfBirth" label="Date of Birth" type="date" value={formData.dateOfBirth} onChange={handleChange} />
                    <CountrySelect id="country" value={formData.country} onChange={handleChange} />
                    <FormInput id="address" label="Residential Address" value={formData.address} onChange={handleChange} placeholder="123 Crypto Lane" />
                </>
            )}
            
            {error && <p className="text-sm text-center text-red-500 dark:text-red-400">{error}</p>}
            
            <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400">
                 {isLoading ? <Loader className="animate-spin" /> : (isLogin ? 'Log In' : 'Sign Up')}
            </button>
        </form>
        <p className="mt-6 text-center text-sm text-gray-600 dark:text-gray-400">
            {isLogin ? "Don't have an account?" : "Already have an account?"}
            <button onClick={() => { setIsLogin(!isLogin); setError(''); }} className="ml-1 font-medium text-purple-600 hover:text-purple-500">
                {isLogin ? 'Sign up' : 'Log in'}
            </button>
        </p>
    </div>
  );
};

// --- Main Component ---

const ProfileScreen = () => {
  const { user, isLoggedIn, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [view, setView] = React.useState('main'); // 'main', 'kyc', 'deposit', etc.

  React.useEffect(() => {
    if (location.state?.view) {
        setView(location.state.view);
        // Clear state after using it
        navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, navigate, location.pathname]);


  if (!isLoggedIn || !user) {
    return (
        <div className="p-4">
            <LoginSignupForm />
        </div>
    );
  }

  const renderView = () => {
    switch (view) {
        case 'kyc':
            return <KycView user={user} onBack={() => setView('main')} />;
        case 'deposit':
            return <DepositView onBack={() => setView('main')} />;
        case 'withdraw':
            return <WithdrawView onBack={() => setView('main')} />;
        case 'notifications':
            return <NotificationsView user={user} onBack={() => setView('main')} />;
        case 'main':
        default:
            return <AssetsView user={user} setView={setView} onLogout={logout} isAdmin={isAdmin} />;
    }
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      {renderView()}
    </div>
  );
};

export default ProfileScreen;
