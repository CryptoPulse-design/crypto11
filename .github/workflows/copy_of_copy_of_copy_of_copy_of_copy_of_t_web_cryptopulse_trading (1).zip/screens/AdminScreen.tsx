
import * as React from 'react';
import { Routes, Route, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { User, KycRequest, PendingDeposit } from '../types.ts';
import { LayoutDashboard, Users, UserCheck, Banknote, LogOut, ArrowLeft, Loader, CheckCircle, XCircle, Home } from 'lucide-react';

// --- Reusable Components ---

const ImageModal = ({ isOpen, onClose, children }: { isOpen: boolean; onClose: () => void; children: React.ReactNode; }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in-fast" onClick={onClose}>
            {children}
        </div>
    );
};


const StatCard = ({ title, value, icon, color }: { title: string; value: string | number; icon: React.ReactNode, color: string }) => (
    <div className={`bg-white dark:bg-slate-800 p-6 rounded-xl shadow-md flex items-center space-x-4 border-l-4 ${color}`}>
        <div className="text-3xl">{icon}</div>
        <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">{title}</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
        </div>
    </div>
);


// --- Main Views ---

const DashboardView = () => {
    const { fetchAllUsers, fetchPendingKyc, fetchPendingDeposits } = useAuth();
    const [stats, setStats] = React.useState({ users: 0, kyc: 0, deposits: 0 });
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const fetchStats = async () => {
            setLoading(true);
            try {
                const [users, kyc, deposits] = await Promise.all([
                    fetchAllUsers(),
                    fetchPendingKyc(),
                    fetchPendingDeposits()
                ]);
                setStats({ users: users.length, kyc: kyc.length, deposits: deposits.length });
            } catch (error) {
                console.error("Failed to fetch admin dashboard stats:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, [fetchAllUsers, fetchPendingKyc, fetchPendingDeposits]);
    
    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>
    }

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">Admin Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Users" value={stats.users} icon={<Users />} color="border-purple-500" />
                <StatCard title="Pending KYC" value={stats.kyc} icon={<UserCheck />} color="border-yellow-500" />
                <StatCard title="Pending Deposits" value={stats.deposits} icon={<Banknote />} color="border-green-500" />
            </div>
        </div>
    );
};

const UsersView = () => {
    const { fetchAllUsers } = useAuth();
    const [users, setUsers] = React.useState<User[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        fetchAllUsers().then(setUsers).finally(() => setLoading(false));
    }, [fetchAllUsers]);

    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>
    }

    return (
         <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">User Management</h1>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-slate-700">
                        <tr>
                            <th className="p-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Name</th>
                            <th className="p-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Email</th>
                            <th className="p-4 text-sm font-semibold text-gray-600 dark:text-gray-300">KYC Status</th>
                            <th className="p-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.uid} className="border-b border-gray-200 dark:border-slate-700">
                                <td className="p-4">{user.name}</td>
                                <td className="p-4">{user.email}</td>
                                <td className="p-4"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.kycStatus === 'verified' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{user.kycStatus}</span></td>
                                <td className="p-4">${user.portfolio.balance.toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

const KycView = () => {
    const { fetchPendingKyc, updateKycStatus, isLoading } = useAuth();
    const [kycQueue, setKycQueue] = React.useState<KycRequest[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedRequest, setSelectedRequest] = React.useState<KycRequest | null>(null);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);

    const loadQueue = React.useCallback(() => {
        setLoading(true);
        fetchPendingKyc().then(setKycQueue).finally(() => setLoading(false));
    }, [fetchPendingKyc]);
    
    React.useEffect(loadQueue, [loadQueue]);

    const handleAction = async (userId: string, status: 'verified' | 'rejected') => {
        setIsProcessing(userId);
        try {
            await updateKycStatus(userId, status);
            setKycQueue(prev => prev.filter(req => req.user.uid !== userId));
            setSelectedRequest(null);
        } catch (error) {
            console.error(`Failed to ${status} KYC for ${userId}:`, error);
        } finally {
            setIsProcessing(null);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;
    }

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">KYC Approval Queue</h1>
            {kycQueue.length === 0 ? (
                <p className="text-center text-gray-500 dark:text-gray-400 py-10">No pending KYC requests.</p>
            ) : (
                <div className="space-y-4">
                    {kycQueue.map(req => (
                        <div key={req.user.uid} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md flex justify-between items-center">
                            <div>
                                <p className="font-bold">{req.user.fullName || req.user.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{req.user.email}</p>
                            </div>
                            <button onClick={() => setSelectedRequest(req)} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                Review
                            </button>
                        </div>
                    ))}
                </div>
            )}
            {selectedRequest && (
                 <ImageModal 
                    isOpen={!!selectedRequest}
                    onClose={() => setSelectedRequest(null)}
                 >
                     <div className="bg-white dark:bg-slate-800 rounded-lg p-6 max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">{`KYC for ${selectedRequest.user.name}`}</h3>
                            <button onClick={() => setSelectedRequest(null)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700">
                                <XCircle size={24} />
                            </button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                             <img src={selectedRequest.kycImages.idFront} alt="ID Front" className="w-full object-contain rounded-md border dark:border-slate-700" />
                             <img src={selectedRequest.kycImages.idBack} alt="ID Back" className="w-full object-contain rounded-md border dark:border-slate-700" />
                        </div>
                         <div className="flex justify-end space-x-3 mt-4">
                            <button
                                disabled={isProcessing === selectedRequest.user.uid}
                                onClick={() => handleAction(selectedRequest.user.uid, 'rejected')}
                                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition flex items-center disabled:opacity-50"
                            >
                                {isProcessing === selectedRequest.user.uid ? <Loader size={20} className="animate-spin mr-2" /> : <XCircle size={20} className="mr-2" />}
                                Reject
                            </button>
                             <button
                                disabled={isProcessing === selectedRequest.user.uid}
                                onClick={() => handleAction(selectedRequest.user.uid, 'verified')}
                                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center disabled:opacity-50"
                            >
                                {isProcessing === selectedRequest.user.uid ? <Loader size={20} className="animate-spin mr-2" /> : <CheckCircle size={20} className="mr-2" />}
                                Approve
                            </button>
                        </div>
                    </div>
                </ImageModal>
            )}
        </div>
    );
};

const DepositsView = () => {
    const { fetchPendingDeposits, updateDepositStatus } = useAuth();
    const [depositQueue, setDepositQueue] = React.useState<PendingDeposit[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedDeposit, setSelectedDeposit] = React.useState<PendingDeposit | null>(null);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);

    const loadQueue = React.useCallback(() => {
        setLoading(true);
        fetchPendingDeposits().then(setDepositQueue).finally(() => setLoading(false));
    }, [fetchPendingDeposits]);
    
    React.useEffect(loadQueue, [loadQueue]);

    const handleAction = async (deposit: PendingDeposit, status: 'Completed' | 'Failed') => {
        setIsProcessing(deposit.transaction.id);
        try {
            await updateDepositStatus(deposit.userId, deposit.transaction.id, status);
            setDepositQueue(prev => prev.filter(d => d.transaction.id !== deposit.transaction.id));
            setSelectedDeposit(null);
        } catch (error) {
            console.error(`Failed to update deposit ${deposit.transaction.id}:`, error);
        } finally {
            setIsProcessing(null);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;
    }

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">Deposit Approval Queue</h1>
             {depositQueue.length === 0 ? (
                <p className="text-center text-gray-500 dark:text-gray-400 py-10">No pending deposit requests.</p>
            ) : (
                <div className="space-y-4">
                    {depositQueue.map(d => (
                        <div key={d.transaction.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md flex justify-between items-center">
                            <div>
                                <p className="font-bold">{d.userName} ({d.userEmail})</p>
                                <p className="text-lg font-semibold text-green-500">+{d.transaction.amount.toLocaleString()} {d.transaction.asset}</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">Network: {d.transaction.network}</p>
                            </div>
                            <button onClick={() => setSelectedDeposit(d)} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                Review Proof
                            </button>
                        </div>
                    ))}
                </div>
            )}
             {selectedDeposit && (
                 <ImageModal 
                    isOpen={!!selectedDeposit}
                    onClose={() => setSelectedDeposit(null)}
                 >
                      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">{`Deposit Proof for ${selectedDeposit.userName}`}</h3>
                            <button onClick={() => setSelectedDeposit(null)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700">
                                <XCircle size={24} />
                            </button>
                        </div>
                        <div className="mb-4">
                             <img src={selectedDeposit.transaction.transactionProof} alt="Transaction Proof" className="max-h-[60vh] mx-auto w-auto object-contain rounded-md border dark:border-slate-700" />
                        </div>
                         <div className="flex justify-end space-x-3 mt-4">
                            <button
                                disabled={isProcessing === selectedDeposit.transaction.id}
                                onClick={() => handleAction(selectedDeposit, 'Failed')}
                                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition flex items-center disabled:opacity-50"
                            >
                                {isProcessing === selectedDeposit.transaction.id ? <Loader size={20} className="animate-spin mr-2" /> : <XCircle size={20} className="mr-2" />}
                                Reject
                            </button>
                             <button
                                disabled={isProcessing === selectedDeposit.transaction.id}
                                onClick={() => handleAction(selectedDeposit, 'Completed')}
                                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center disabled:opacity-50"
                            >
                                {isProcessing === selectedDeposit.transaction.id ? <Loader size={20} className="animate-spin mr-2" /> : <CheckCircle size={20} className="mr-2" />}
                                Approve
                            </button>
                        </div>
                    </div>
                </ImageModal>
            )}
        </div>
    );
};


// --- Main Admin Layout ---

const AdminSidebar = () => {
    const { logout } = useAuth();
    const navigate = useNavigate();
    const NavItem = ({ to, icon, label }: { to:string, icon:React.ReactNode, label:string }) => {
        const baseClasses = "flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200";
        const inactiveClasses = "text-gray-600 dark:text-gray-300 hover:bg-purple-100 hover:text-purple-700 dark:hover:bg-slate-700";
        const activeClasses = "bg-purple-600 text-white font-semibold shadow-lg";
        return (
             <NavLink to={to} className={({isActive}) => `${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
                {icon}
                <span>{label}</span>
            </NavLink>
        );
    }

    return (
        <aside className="w-64 bg-white dark:bg-slate-800/50 p-4 flex flex-col border-r border-gray-200 dark:border-slate-700/50">
            <div className="flex items-center space-x-2 mb-10">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-purple-600 to-blue-500"></div>
                <h2 className="text-xl font-bold">CryptoPulse</h2>
            </div>
            <nav className="flex-1 space-y-2">
                <NavItem to="/admin" icon={<LayoutDashboard size={20} />} label="Dashboard" />
                <NavItem to="/admin/users" icon={<Users size={20} />} label="Users" />
                <NavItem to="/admin/kyc" icon={<UserCheck size={20} />} label="KYC Queue" />
                <NavItem to="/admin/deposits" icon={<Banknote size={20} />} label="Deposits Queue" />
            </nav>
            <div className="mt-auto space-y-2">
                 <button onClick={() => navigate('/')} className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200 text-gray-600 dark:text-gray-300 hover:bg-purple-100 hover:text-purple-700 dark:hover:bg-slate-700">
                    <Home size={20} />
                    <span>Back to App</span>
                </button>
                 <button onClick={logout} className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200 text-red-500 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/50">
                    <LogOut size={20} />
                    <span>Log Out</span>
                </button>
            </div>
        </aside>
    );
};

const AdminScreen = () => {
    return (
        <div className="flex min-h-screen bg-gray-100 dark:bg-black text-slate-900 dark:text-white">
            <AdminSidebar />
            <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
                <Routes>
                    <Route index element={<DashboardView />} />
                    <Route path="users" element={<UsersView />} />
                    <Route path="kyc" element={<KycView />} />
                    <Route path="deposits" element={<DepositsView />} />
                </Routes>
            </main>
        </div>
    );
};

export default AdminScreen;