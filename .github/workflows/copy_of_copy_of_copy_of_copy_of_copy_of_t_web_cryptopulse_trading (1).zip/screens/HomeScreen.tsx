
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Download, Scale, Headset, Volume2 } from 'lucide-react';
import type { CryptoCoin } from '../types.ts';
import { useAppContext } from '../contexts/AppContext.tsx';

const carouselSlides = [
    {
        bg: 'https://images.unsplash.com/photo-1642147291848-185d95d85262?q=80&w=2070&auto=format&fit=crop',
        title: "Absolute Return Strategy",
        subtitle: "Minimal correlation with traditional assets",
        content: <div className="text-center mt-2"><p className="text-sm">Annualized return</p><p className="text-4xl font-bold tracking-tighter">15.35%</p></div>
    },
    {
        bg: 'https://images.unsplash.com/photo-1593693397649-6d81e0a8a7a3?q=80&w=2070&auto=format&fit=crop',
        title: "Global Charity Alliance",
        subtitle: "Your trades make a difference",
        logos: [
            'https://logowik.com/content/uploads/images/the-giving-block4961.logowik.com.webp',
            'https://logowik.com/content/uploads/images/unchained-capital5623.logowik.com.webp',
            'https://logowik.com/content/uploads/images/bitcoin-foundation1129.logowik.com.webp',
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/22.png',
        ]
    }
];

const commodityData: CryptoCoin[] = [
    { id: 'gold', symbol: 'XAU', name: 'Gold', image: '', current_price: 2318.50, price_change_percentage_24h: 0.48, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'silver', symbol: 'XAG', name: 'Silver', image: '', current_price: 29.50, price_change_percentage_24h: -0.06, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'oil', symbol: 'WTI', name: 'Crude Oil', image: '', current_price: 80.25, price_change_percentage_24h: 15.25, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'natural-gas', symbol: 'NG', name: 'Natural Gas', image: '', current_price: 2.91, price_change_percentage_24h: 0.00, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'corn', symbol: 'CORN', name: 'Corn', image: '', current_price: 450.75, price_change_percentage_24h: -7.06, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
];


const actionMenuItems = [
    { icon: CreditCard, label: 'Recharge', path: '/profile', state: { view: 'deposit' } },
    { icon: Download, label: 'Withdraw', path: '/profile', state: { view: 'withdraw' } },
    { icon: Scale, label: 'Balance', path: '/profile', state: {} },
    { icon: Headset, label: 'Consult', action: 'openTelegram' },
];

const HomeScreen = () => {
    const navigate = useNavigate();
    const { openTelegramModal } = useAppContext();
    const [activeSlide, setActiveSlide] = React.useState(0);
    const [activeTab, setActiveTab] = React.useState('Hot');
    const [marketData, setMarketData] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const fetchCoinData = async () => {
            setLoading(true);
            try {
                const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
                if (!response.ok) {
                    throw new Error('Failed to fetch data');
                }
                const data: CryptoCoin[] = await response.json();
                setMarketData(data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchCoinData();
        const intervalId = setInterval(fetchCoinData, 30000);

        return () => clearInterval(intervalId);
    }, []);
    
    React.useEffect(() => {
        if (carouselSlides.length <= 1) return;
        const timer = setTimeout(() => {
            setActiveSlide((prev) => (prev + 1) % carouselSlides.length);
        }, 5000);
        return () => clearTimeout(timer);
    }, [activeSlide]);

    const handleActionClick = (item) => {
        if (item.action === 'openTelegram') {
            openTelegramModal();
        } else {
            navigate(item.path, { state: item.state });
        }
    };
    
    const MarketRow = ({ coin, isCommodity = false }: { coin: CryptoCoin; isCommodity?: boolean }) => {
        const isPositive = (coin.price_change_percentage_24h || 0) >= 0;
        const changeColor = isPositive ? 'text-green-500' : 'text-red-500';
        const changeSign = isPositive ? '+' : '';
        const pairSymbol = isCommodity ? `${coin.symbol.toUpperCase()}-USD` : `${coin.symbol.toUpperCase()}-USDT`;

        return (
            <div 
                className="grid grid-cols-3 items-center py-3 px-2 rounded-md hover:bg-slate-800/50 cursor-pointer transition-colors"
                onClick={() => navigate(`/trading/${pairSymbol}`)}
            >
                <div className="text-left">
                    <p className="font-bold">{isCommodity ? coin.name : `${coin.symbol.toUpperCase()}/USDT`}</p>
                </div>
                <p className="text-center font-semibold">{coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</p>
                <p className={`text-right font-semibold ${changeColor}`}>{changeSign}{(coin.price_change_percentage_24h || 0).toFixed(2)}%</p>
            </div>
        );
    };

    return (
        <div className="bg-black text-white min-h-screen pb-24 font-sans">
            <header className="py-4">
                <h1 className="text-xl font-bold text-center">Home</h1>
            </header>

            <main className="px-4 space-y-6">
                {/* Carousel */}
                <div className="relative w-full h-44 bg-slate-800 rounded-lg overflow-hidden group">
                     {carouselSlides.map((slide, index) => (
                        <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ${index === activeSlide ? 'opacity-100' : 'opacity-0'}`}>
                            <img src={slide.bg} alt={slide.title} className="w-full h-full object-cover"/>
                            <div className="absolute inset-0 bg-black/60 p-6 flex flex-col justify-between">
                                <div>
                                    <h2 className="text-2xl font-bold uppercase">{slide.title}</h2>
                                    <h3 className="text-xl uppercase text-gray-300">{slide.subtitle}</h3>
                                </div>
                                {slide.content ? (
                                    slide.content
                                ) : slide.logos ? (
                                    <div className="flex items-center space-x-4">
                                        {slide.logos.map((logo, logoIndex) => (
                                            <img key={logoIndex} src={logo} alt="exchange logo" className="h-8 w-8 bg-white/20 rounded-full p-1 object-contain"/>
                                        ))}
                                    </div>
                                ) : null}
                            </div>
                        </div>
                    ))}
                     <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-2">
                        {carouselSlides.map((_, index) => (
                            <button key={index} onClick={() => setActiveSlide(index)} className={`w-2 h-2 rounded-full transition-colors ${index === activeSlide ? 'bg-purple-500' : 'bg-gray-400'}`}></button>
                        ))}
                    </div>
                </div>

                {/* Announcement Bar */}
                <div className="flex items-center space-x-3 bg-slate-800/50 p-2 rounded-lg text-sm overflow-hidden">
                    <Volume2 size={20} className="text-purple-400 flex-shrink-0" />
                    <div className="flex-grow whitespace-nowrap">
                         <p className="animate-marquee inline-block">Upgrade Announcement: Trading fees for all BTC pairs reduced by 50% for a limited time!</p>
                    </div>
                    <button className="text-purple-400 font-semibold flex-shrink-0">More&gt;</button>
                </div>

                {/* Quick Action Menu */}
                <div className="grid grid-cols-4 gap-4 text-center">
                    {actionMenuItems.map((item, index) => (
                        <button key={index} onClick={() => handleActionClick(item)} className="flex flex-col items-center space-y-2">
                            <item.icon size={28} className="text-purple-400" />
                            <span className="text-sm font-medium">{item.label}</span>
                        </button>
                    ))}
                </div>

                {/* Market Data */}
                <div>
                    <div className="flex space-x-6 border-b border-slate-700 mb-2">
                         <button onClick={() => setActiveTab('Hot')} className={`py-2 font-semibold transition-colors ${activeTab === 'Hot' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Hot
                        </button>
                         <button onClick={() => setActiveTab('Commodity')} className={`py-2 font-semibold transition-colors ${activeTab === 'Commodity' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Commodity
                        </button>
                    </div>

                    <div>
                        <div className="grid grid-cols-3 text-sm text-gray-500 mb-2 px-2">
                            <p className="text-left">Products</p>
                            <p className="text-center">Last price</p>
                            <p className="text-right">24H Change</p>
                        </div>
                        <div className="space-y-1">
                            {loading && activeTab === 'Hot' && <p className="text-center text-gray-400 py-4">Loading...</p>}
                            {!loading && activeTab === 'Hot' && marketData.map(coin => <MarketRow key={coin.id} coin={coin} />)}
                            {activeTab === 'Commodody' && commodityData.map(coin => <MarketRow key={coin.id} coin={coin} isCommodity={true} />)}
                        </div>
                         <div className="text-center mt-4">
                           <button onClick={() => navigate('/markets')} className="text-gray-500 hover:text-white transition-colors text-sm font-medium">
                               Check for more
                           </button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomeScreen;